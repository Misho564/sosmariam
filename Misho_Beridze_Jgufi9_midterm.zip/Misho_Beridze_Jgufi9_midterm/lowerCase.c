#include <stdio.h>
#include <stdlib.h>

#define MAXLINE 100

int countLower(char line[], int maxline);
void copy(char to[], char from[]);
int myGetchar();

int main() 

{
    int lower;
    int max;
    char line[MAXLINE];
    char mostLower[MAXLINE];
    
     
    max = 0;

    while ((lower = countLower(line, MAXLINE)) > 0)
        if (lower > max){
            max = lower;
            copy(mostLower, line);
        }

    if (max > 0){
        printf("\nline with most lowercase characters : %d\n", max);
        perror("printf error");
    return 0;
    }
}
 
int countLower(char s[], int lim){

    int c, i, lower_char;
    lower_char = 0;
     
    for (i=0; i<lim-1 && (c=myGetchar()) !=EOF && c!='\n'; ++i)
    {
        if (c >= 'A' && c <= 'Z')
        {
            ++lower_char;
        }
        else{
        s[i] = c;
    }
    }

    if (c == '\n')
    {
        s[i] = c;
        ++i;
    }

    s[i] = '\0';

    return lower_char;

}
 
void copy(char to[], char from[])

{

    int i = 0;

    while ((to[i] = from[i]) != '\0')
        ++i;

}



int myGetchar()
{
    int c;
    
    if((c = getchar()) == EOF)
    {
        if(feof(stdin))
        {
            perror("\nend-of-file");
        }

        if(ferror(stdin))
        {
            perror("getchar error");
            exit(1);          
        } 

    }
    return c;
}



