#include <stdio.h>
#include <stdlib.h>
int main
    {
        return 0;
    }


int countLower(char s[], int lim){

    int c, i, lower_char;
    lower_char = 0;
     
    for (i=0; i<lim-1 && (c=myGetchar()) !=EOF && c!='\n'; ++i)
    {
        if (c >= 'A' && c <= 'Z')
        {
            ++lower_char;
        }
        else{
        s[i] = c;
    }
    }

    if (c == '\n')
    {
        s[i] = c;
        ++i;
    }

    s[i] = '\0';

    return lower_char;

}
