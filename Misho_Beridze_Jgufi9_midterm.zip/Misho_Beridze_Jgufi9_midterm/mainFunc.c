#include <stdio.h>
#include <stdlib.h>

#define MAXLINE 100

int countLower(char line[], int maxline);
void copy(char to[], char from[]);
int myGetchar();

int main() 

{
    int lower;
    int max;
    char line[MAXLINE];
    char mostLower[MAXLINE];
    
     
    max = 0;

    while ((lower = countLower(line, MAXLINE)) > 0)
        if (lower > max){
            max = lower;
            copy(mostLower, line);
        }

    if (max > 0){
        printf("\nline with most lowercase characters : %d\n", max);
        perror("printf error");
    return 0;
    }
}
