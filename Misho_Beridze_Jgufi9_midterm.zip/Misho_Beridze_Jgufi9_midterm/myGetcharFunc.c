#include <stdio.h>
#include <stdlib.h>
int main
    {
        return 0;
    }

int myGetchar()
{
    int c;
    
    if((c = getchar()) == EOF)
    {
        if(feof(stdin))
        {
            perror("\nend-of-file");
        }

        if(ferror(stdin))
        {
            perror("getchar error");
            exit(1);          
        } 

    }
    return c;
}


