#include <stdio.h>
#include <stdlib.h>
int main
    {
        return 0;
    }

void copy(char to[], char from[])

{

    int i = 0;

    while ((to[i] = from[i]) != '\0')
        ++i;

}

